# Zt=function(X,t) X*(exp(t)-1)
# Lambdat=function(t) 0.2*t

Gen_obj=function(t,X,beta,U,Lambdat,Zt){
  result=Lambdat(t)+sum(beta*Zt(X,t))+log(U)
  return(result)
}
Gen_T=function(X,beta,Lambdat,Zt){
  n=nrow(X)
  U=runif(n,0,1)
  Timelist=rep(0,n)
  for (i in 1:n) {
    Tresult=nleqslv::nleqslv(x=0.1,fn=Gen_obj,X=X[i,],beta=beta,U=U[i],Lambdat=Lambdat,Zt=Zt)
    Timelist[i]=Tresult$x
  }
  return(Timelist)
}
Data_generation=function(n,beta,Lambdat,Zt){
  betadim=length(beta)
  X=matrix(rbinom(n*betadim,1,0.5), nrow = n, ncol = betadim)
  U=runif(n,0,1)
  TimeToEvent=Gen_T(X,beta,Lambdat,Zt)
  TimeToEvent=matrix(TimeToEvent)
  L=runif(n,0.1,2)
  R=runif(n,L+0.5,4)
  InspectTime=matrix(0, nrow = n, ncol = 2)
  InspectTime[,1]=L
  InspectTime[,2]=R
  Delta=matrix(0, nrow = n, ncol = 3)
  for (i in 1:n) {
    Delta[i,1]=as.numeric(TimeToEvent[i]<=InspectTime[i,1])
    Delta[i,3]=as.numeric(TimeToEvent[i]>InspectTime[i,2])
    Delta[i,2]=1-Delta[i,1]-Delta[i,3]
  }
  mimicTime=InspectTime
  InspectTime[,2]=InspectTime[,2]*(1-Delta[,1])
  InspectTime[,1]=InspectTime[,1]*(1-Delta[,3])
  minvalue=min(InspectTime[InspectTime>0])
  mimicTime[mimicTime<=minvalue]=minvalue
  
  ConsisData=matrix(0,nrow = n,ncol=2)
  for(i in 1:n){
    if(Delta[i,1]==1){
      ConsisData[i,2]=InspectTime[i,1]
    }
    else if(Delta[i,3]==1){
      ConsisData[i,1]=InspectTime[i,2]
      ConsisData[i,2]=Inf
    }
    else{
      ConsisData[i,]=InspectTime[i,]
    }
  }
  # return(list(X=X,Delta=Delta,Inspec=InspectTime,mimic=mimicTime))
  finalresult=cbind(ConsisData,Delta,X)
  Firstfivename=c("left.inspec","right.inspec","left.censoring","interval.censoring","right.censoring")
  covname=c()
    for (i in 1:betadim) {
    covname=append(covname,paste("covariate",i,sep = "_"))
    }
  colnames(finalresult)=c(Firstfivename,covname)
  return(finalresult)
}

Main_func_ind=function(data,hn.m,Max_iter=1000,Tol=1e-3){
  Delta=data[,3:5]
  X=as.matrix(data[,6:ncol(data)])
  n=nrow(X)
  Inspec=matrix(0,nrow=n,ncol=2)
  mimic=matrix(0,nrow=n,ncol=2)
  rawInspec=data[,1:2]
  minInspec=min(rawInspec[rawInspec>0])
  for(i in 1:n){
    if(Delta[i,1]==1){
      Inspec[i,1]=data[i,2]
      mimic[i,]=Inspec[i,]
      mimic[i,2]=Inspec[i,1]+1
    }
    else if(Delta[i,3]==1){
      Inspec[i,2]=data[i,1]
      mimic[i,]=Inspec[i,]
      mimic[i,1]=minInspec
    }
    else{
      Inspec[i,]=data[i,1:2]
      mimic[i,]=Inspec[i,1:2]
    }
  }
  
  result1C=Main_func_cpp(X,Delta,Inspec,mimic,Max_iter,Tol)
  betadim=ncol(X)
  hn=hn.m*n^(-1/2)
  if(betadim==1){
    seC=SE_cal_cpp_one(matrix(result1C[[1]]),matrix(result1C[[2]]),as.numeric(result1C[[3]]),X,Delta,Inspec,mimic,1000,1e-3,hn)
  }
  else{
    seC=SE_cal_cpp(matrix(result1C[[1]]),matrix(result1C[[2]]),as.numeric(result1C[[3]]),X,Delta,Inspec,mimic,1000,1e-3,hn)
  }
  betaest=result1C[[1]]
  lambdaest=exp(result1C[[2]])
  log_likelihood=as.numeric(result1C[[3]])
  betaresult=matrix(0, nrow = betadim, ncol = 2)
  betaresult[,1]=betaest
  betaresult[,2]=seC
  colnames(betaresult)=c("Est","SE")
  finalresult=list(beta=betaresult,lambda=lambdaest,log.likelihood=log_likelihood)
  return(finalresult)
}

Main_func_Expt=function(data,hn.m,Max_iter=1000,Tol=1e-3){
  Delta=data[,3:5]
  X=matrix(data[,-(1:5)])
  n=nrow(X)
  Inspec=matrix(0,nrow=n,ncol=2)
  mimic=matrix(0,nrow=n,ncol=2)
  rawInspec=data[,1:2]
  minInspec=min(rawInspec[rawInspec>0])
  for(i in 1:n){
    if(Delta[i,1]==1){
      Inspec[i,1]=data[i,2]
      mimic[i,]=Inspec[i,]
      mimic[i,2]=Inspec[i,1]+1
    }
    else if(Delta[i,3]==1){
      Inspec[i,2]=data[i,1]
      mimic[i,]=Inspec[i,]
      mimic[i,1]=minInspec
    }
    else{
      Inspec[i,]=data[i,1:2]
      mimic[i,]=Inspec[i,1:2]
    }
  }
  result1C=Main_func_Dep(X,Delta,Inspec,mimic,Max_iter,Tol)
  betadim=ncol(X)
  hn=hn.m*n^(-1/2)
  seC=SE_cal_Dep_one(matrix(result1C[[1]]),matrix(result1C[[2]]),as.numeric(result1C[[3]]),X,Delta,Inspec,mimic,1000,1e-3,hn)
  betaest=result1C[[1]]
  lambdaest=exp(result1C[[2]])
  log_likelihood=as.numeric(result1C[[3]])
  betaresult=matrix(0, nrow = betadim, ncol = 2)
  betaresult[,1]=betaest
  betaresult[,2]=seC
  colnames(betaresult)=c("Est","SE")
  finalresult=list(beta=betaresult,lambda=lambdaest,log.likelihood=log_likelihood)
  return(finalresult)
}


